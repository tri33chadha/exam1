/************************************************************************************
 -> File                 : EnquiryDao.java
 -> Author Name          : Ashish Dhar
 -> Desc                 : DAO interface methods
 -> Version              : 1.0
 -> Last Modified Date   : 02-May-2019
 ************************************************************************************/

package com.cg.enquiry.dao;

import com.cg.enquiry.bean.DemandDraftBean;
import com.cg.enquiry.exception.EnquiryDBException;
import com.cg.enquiry.exception.InvalidEnquiryException;

public interface EnquiryDao {
	public String addEnquiry(DemandDraftBean enquiry) throws EnquiryDBException;
	public DemandDraftBean getEnquiryDetails(String enquiryId) throws EnquiryDBException;
}
