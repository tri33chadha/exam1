/************************************************************************************
 -> File                 : EnquiryDaoImpl.java
 -> Author Name          : Ashish Dhar
 -> Desc                 : DAO implementation implements EnquiryDao
 -> Version              : 1.0
 -> Last Modified Date   : 02-May-2019
 ************************************************************************************/

package com.cg.enquiry.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;


import org.apache.log4j.PropertyConfigurator;

import com.cg.enquiry.bean.DemandDraftBean;
import com.cg.enquiry.exception.EnquiryDBException;
import com.cg.enquiry.util.DBUtil;

public class EnquiryDaoImpl implements EnquiryDao {
	
	//Initializing apache logger
	Logger logger = Logger.getRootLogger();
	Connection conn = null;
	public EnquiryDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	/***************************************************************************
	 -> Function Name	    :	generateEnquiryId()
	 -> Return Type		    :	String
	 -> Throws			    :  	EnquiryDBException
	 -> Description		    :	Generate enquiry id with sequence
	 ***************************************************************************/
	private String generateEnquiryId() throws EnquiryDBException{
		String eid = null;
		try {
			conn = DBUtil.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rst  = stmt.executeQuery(QueryMapper.ENQUIRYID_SEQUENCE_QUERY);
			while(rst.next()){
				eid = rst.getString(1);
			}

		} catch (SQLException e) {
			logger.error("Problem in generating enquiry id\n"+e.getMessage());
			throw new EnquiryDBException("Problem in generating enquiry id");
		}
		return eid;
		
	}

	/***************************************************************************
	 -> Function Name	    :	addEnquiry(EnquiryBean enquiry)
	 -> Return Type		    :	String
	 -> Throws			    :  	EnquiryDBException
	 -> Description		    :	Adds enquiry details
	 ***************************************************************************/
	@Override
	public String addEnquiry(DemandDraftBean enquiry) throws EnquiryDBException {
		enquiry.setTransaction_Id(generateEnquiryId());
		try {
			conn = DBUtil.getConnection();
			PreparedStatement pst = conn.prepareStatement(QueryMapper.ADD_ENQUERY_QUERY);
			pst.setString(1, enquiry.getTransaction_Id());
			pst.setString(2, enquiry.getCustomer_Name());
			pst.setString(3, enquiry.getIn_favor_of());
			pst.setString(4, enquiry.getDate_of_transaction());
			pst.setString(5, enquiry.getPhone_number());
			pst.setString(6, enquiry.getDd_amount());
			pst.setString(7, enquiry.getDd_comm());
			pst.setString(8, enquiry.getDd_description());
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error("Enquiry details insertion failed"+e.getMessage());
			throw new EnquiryDBException("Problem in adding enquiry details\n");
		}
		return enquiry.getTransaction_Id();
	}
	
	/***************************************************************************
	 -> Function Name	    :	getEnquiryDetails(String enquiryId)
	 -> Return Type		    :	String
	 -> Throws			    :  	EnquiryDBException
	 -> Description		    :	Gets enquiry details with by id
	 ***************************************************************************/
	@Override
	public DemandDraftBean getEnquiryDetails(String enquiryId) throws EnquiryDBException {
		DemandDraftBean enq = null;
		try {
			conn = DBUtil.getConnection();
			PreparedStatement pst = conn.prepareStatement(QueryMapper.GET_ENQUIRY_QUERY);
			pst.setString(1, enquiryId);
			ResultSet rst = pst.executeQuery();
			if(rst.next()){
				enq = new DemandDraftBean();
				enq.setTransaction_Id(rst.getString("enqryid"));
				enq.setCustomer_Name(rst.getString("Customer name"));
				enq.setIn_favor_of(rst.getString("In-favour"));
				enq.setPhone_number(rst.getString("contactno"));
				enq.setDd_amount(rst.getString("Amount"));
				enq.setDd_comm(rst.getString("comm"));
				enq.setDd_description(rst.getString("Description"));
			}
		} catch (SQLException e) {
			logger.error("Problem in serching enquiry details\n"+ e.getMessage());
			throw new EnquiryDBException("Problem in searching enquiry details\n");
		}
		return enq;
	}

}
