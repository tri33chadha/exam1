/************************************************************************************
 -> File                 : QueryMapper.java
 -> Author Name          : Ashish Dhar
 -> Desc                 : Interface for defining queries
 -> Version              : 1.0
 -> Last Modified Date   : 02-May-2019
 ************************************************************************************/
package com.cg.enquiry.dao;

public interface QueryMapper {
	public static final String GET_ENQUIRY_QUERY="SELECT tractionId,customerName,in_favor_of,contactno,dateOfTransaction,dd_ammount,dd_comm,dd_description FROM demand_draft WHERE tractionId=?";
	public static final String ADD_ENQUERY_QUERY="INSERT INTO demand_draft VALUES(?,?,?,?,?,?,?)";
	public static final String ENQUIRYID_SEQUENCE_QUERY="SELECT Transaction_id_Seq.NEXTVAL FROM DUAL";
	//public static final String ADD_ENQUERY_QUERY = null;

}
