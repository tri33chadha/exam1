/************************************************************************************
 -> File                 : EnquiryBean.java
 -> Author Name          : Ashish Dhar
 -> Desc                 : Create the entities for EnquiryBean class
 -> Version              : 1.0
 -> Last Modified Date   : 02-May-2019
 ************************************************************************************/
package com.cg.enquiry.bean;

import java.util.Date;

public class DemandDraftBean {

	private String transaction_Id;
	private String customer_Name;
	private String In_favor_of;
	private String phone_number;
	private String date_of_transaction;
	private String dd_amount;
	private String dd_comm;
	private String dd_description;

	/******************************************
	 * -> Default constructor initialized
	 ******************************************/
	public DemandDraftBean() {

	}

	/******************************************
	 * -> Parameterized constructor initialized
	 ******************************************/

	public DemandDraftBean(String transaction_Id, String customer_Name, String in_favor_of, String phone_number,
			String date_of_transaction, String dd_amount, String dd_comm, String dd_description) {
		super();
		this.transaction_Id = transaction_Id;
		this.customer_Name = customer_Name;
		In_favor_of = in_favor_of;
		this.phone_number = phone_number;
		this.date_of_transaction = date_of_transaction;
		this.dd_amount = dd_amount;
		this.dd_comm = dd_comm;
		this.dd_description = dd_description;
	}

	/******************************************
	 * -> Generating getters and setters
	 ******************************************/

	public String getTransaction_Id() {
		return transaction_Id;
	}

	public void setTransaction_Id(String transaction_Id) {
		this.transaction_Id = transaction_Id;
	}

	public String getCustomer_Name() {
		return customer_Name;
	}

	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}

	public String getDate_of_transaction() {
		return date_of_transaction;
	}

	public void setDate_of_transaction(String date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}

	public String getDd_amount() {
		return dd_amount;
	}

	public void setDd_amount(String dd_amount) {
		this.dd_amount = dd_amount;
	}

	public String getDd_comm() {
		return dd_comm;
	}

	public void setDd_comm(String dd_comm) {
		this.dd_comm = dd_comm;
	}

	public String getDd_description() {
		return dd_description;
	}

	public void setDd_description(String dd_description) {
		this.dd_description = dd_description;
	}

	public String getIn_favor_of() {
		return In_favor_of;
	}

	public void setIn_favor_of(String in_favor_of) {
		In_favor_of = in_favor_of;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	/******************************************
	 * -> Generating toString method
	 ******************************************/
	@Override
	public String toString() {
		return "DemandDraftBean [transaction_Id=" + transaction_Id + ", customer_Name=" + customer_Name
				+ ", In_favor_of=" + In_favor_of + ", phone_number=" + phone_number + ", date_of_transaction="
				+ date_of_transaction + ", dd_amount=" + dd_amount + ", dd_comm=" + dd_comm + ", dd_description="
				+ dd_description + "]";
	}

}
