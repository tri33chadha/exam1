/************************************************************************************
 -> File                 : EnquiryMain.java
 -> Author Name          : Ashish Dhar
 -> Desc                 : Takes input from console and do appropriate operation
 -> Version              : 1.0
 -> Last Modified Date   : 02-May-2019
 ************************************************************************************/
package com.cg.enquiry.pl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.enquiry.bean.DemandDraftBean;
import com.cg.enquiry.exception.EnquiryDBException;
import com.cg.enquiry.exception.InvalidEnquiryException;
import com.cg.enquiry.service.EnquiryService;
import com.cg.enquiry.service.EnquiryServiceImpl;

public class EnquiryMain {

	static Logger logger = Logger.getRootLogger();
	static SimpleDateFormat myFormat = new SimpleDateFormat("dd mm yyyy");

	public static void main(String[] args) throws ParseException, EnquiryDBException {
		PropertyConfigurator.configure("resources/log4j.properties");
		EnquiryService eser = new EnquiryServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("============================================");
			System.out.println("||              SELECT MENU               ||");
			System.out.println("============================================");
			System.out.println("|       1. Enter Demand draft Details      |");
			System.out.println("|       2. View DD Details Enter ID        |");
			System.out.println("|       3. Exit                            |");
			System.out.println("============================================");
			System.out.println("Please Enter your choice\n");
			String choice = sc.nextLine();

			switch (choice) {
			case "1":
				/*******************************************
				 * -> Case for adding enquiry
				 *******************************************/
				System.out.println("Please enter Customer name : ");
				String cname = sc.nextLine();
				System.out.println("Please enter DD in favour of : ");
				String fname = sc.nextLine();
				System.out.println("Please enter phone  Numeber : ");
				String contact = sc.nextLine();
				System.out.println("Please Enter Date of Transaction : ");
				String dtrans = sc.nextLine();
				// String dtrans = sc.nextLine();
				// String date = myFormat.parse(dtrans);
				System.out.println("Please enter DD Ammount : ");
				String amount = sc.nextLine();
				System.out.println("Please enter DD comm : ");
				String dcomm = sc.nextLine();
				System.out.println("Please enter DD Description : ");
				String description = sc.nextLine();
				DemandDraftBean enquiry = new DemandDraftBean(null, cname, fname, contact, dtrans, amount, dcomm,
						description);
				try {
					if (eser.isValidEnquiry(enquiry)) {
						String eid = eser.addEnquiry(enquiry);
						logger.info("Enquiry details inserted in table with id " + eid);
						System.out
								.println("Thank you " + enquiry.getCustomer_Name() + "Your Demad Draft has been ready "
										+ enquiry.getTransaction_Id() + " \n" + "Your unique id is "
										+ enquiry.getTransaction_Id() + " " + "We will contact you soon");
					}
				} catch (InvalidEnquiryException e) {
					logger.error("Invalid data" + e.getMessage());
					System.err.println(e.getMessage());
				}
				break;
			case "2":
				/*******************************************
				 * -> Case for searching enquiry with id
				 *******************************************/
				System.out.println("Please enter the Draft id you want to search");
				System.out.println("*Note : Draft id is started from 100001");
				String enquiryId = sc.nextLine();
				try {
					System.out.println("Search result is :\n");
					DemandDraftBean enquBean;
					enquBean = eser.getDetail(enquiryId);
					if (enquBean == null) {
						System.err.println("Sorry no details found with id " + enquiryId + " !!!");
					} else {
						System.out.println("Transaction ID  : " + enquBean.getTransaction_Id());
						System.out.println("Customer Name  : " + enquBean.getCustomer_Name());
						System.out.println("In Favour of   : " + enquBean.getIn_favor_of());
						System.out.println("Contact No  : " + enquBean.getPhone_number());
						System.out.println("Date of Trassaction      : " + enquBean.getDate_of_transaction());
						System.out.println("Amount    : " + enquBean.getDd_amount());
						System.out.println("DD Comm    : " + enquBean.getDd_comm());
						System.out.println("Description    : " + enquBean.getDd_description());

					}
				} catch (EnquiryDBException e) {
					logger.error("Problem in searching enquiry details /n" + e.getMessage());
					System.err.println(e.getMessage());
				}
				break;
			case "3":
				/*******************************************
				 * -> Case for existing from menu
				 *******************************************/
				System.out.println("Thank you for selecting us !!!");
				System.exit(0);
				break;
			default:
				/*******************************************
				 * -> Default case for invalid choice
				 *******************************************/
				logger.info("Invalid choice");
				System.err.println("You have entered an invalid choice ... Please try again!");
				break;
			}

		} while (true);

	}

}
