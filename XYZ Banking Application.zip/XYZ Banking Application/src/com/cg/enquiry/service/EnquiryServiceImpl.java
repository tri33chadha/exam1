/************************************************************************************
 -> File                 : EnquiryServiceImpl.java
 -> Author Name          : Ashish Dhar
 -> Desc                 : EnquiryServiceImpl implements enquiry service
 -> Version              : 1.0
 -> Last Modified Date   : 02-May-2019
 ************************************************************************************/
package com.cg.enquiry.service;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.enquiry.bean.DemandDraftBean;
import com.cg.enquiry.dao.EnquiryDao;
import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.exception.EnquiryDBException;
import com.cg.enquiry.exception.InvalidEnquiryException;

public class EnquiryServiceImpl implements EnquiryService {
	
	//Initializing apache logger
	Logger logger = Logger.getRootLogger();
	EnquiryDao edao = new EnquiryDaoImpl();
	
	public EnquiryServiceImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
//
//	@Override
//	public String addEnquiry(DemandDraftBean enquiry) throws EnquiryDBException {
//		return edao.addEnquiry(enquiry);
//	}
//
//	@Override
//	public DemandDraftBean getEnquiryDetails(String enquiryId) throws EnquiryDBException {
//		return edao.getEnquiryDetails(enquiryId);
//	}
	@Override
	public String addDemandDraft(DemandDraftBean enquiry) throws EnquiryDBException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public DemandDraftBean getDetail(String enquiryId) throws EnquiryDBException {
		// TODO Auto-generated method stub
		return edao.getEnquiryDetails(enquiryId);
	}
	@Override
	public String addEnquiry(DemandDraftBean enquiry) throws EnquiryDBException {
		// TODO Auto-generated method stub
		return edao.addEnquiry(enquiry);
	}
	
	/* Validating all user data */
	@Override
	public boolean isValidEnquiry(DemandDraftBean enquiry) throws InvalidEnquiryException {
		if(!enquiry.getCustomer_Name().matches("^[A-Z][a-z]{2,14}$")){
			logger.error("Customer name is not correct");
			throw new InvalidEnquiryException("Please enter a correct Customer name\n"
					+ "First name should start with capital letter and it should be of 3-15 letters");
		}if(!enquiry.getIn_favor_of().matches("^[A-Z][a-z]{2,14}$")){
			logger.error("In-favour name is not correct");
			throw new InvalidEnquiryException("Please enter a correct In-favour\n"
					+ "In-favour should start with capital letter and it should be of 3-15 letters");
		}if(!enquiry.getPhone_number().matches("^[6-9][0-9]{9}$")){
			logger.error("Contact number is not correct");
			throw new InvalidEnquiryException("Please enter a correct contact number!!!\n "
					+ "Contact number should be of 10 digits and it should start from 6 onwards");
		}if(Integer.parseInt(enquiry.getDd_amount())<100){
			System.out.println("Enter value Greater then 100");
			logger.error("Amount is not correct");
			throw new InvalidEnquiryException("Please enter a correct Amount\n"
					+ "Enetered Amount should be Greater then 100");
		}
		return true;
	}


}
